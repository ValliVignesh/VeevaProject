package com.veevaAssignment.CPDP.pages;

import com.veevaAssignment.CPDP.objectRepository.NBAWarriorsHomePageObjects;
import com.veevaAssignment.generic.keywords.GenericKeywords;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.testng.Assert;

import java.time.Duration;

/**
 * Class containing actions that can be performed on the NBA Warriors Home page.
 * Extends GenericKeywords to leverage common web interaction methods.
 */
public class WarriorsHomePageActions extends GenericKeywords {

    /** Constructs a new instance */
    public  WarriorsHomePageActions(){}

    private final NBAWarriorsHomePageObjects warriorsHomePageObjects = new NBAWarriorsHomePageObjects();

    /**
     * Waits for the ads iframe to become visible on the page.
     */
    public void waitForAds(){
        waitUntilVisible( warriorsHomePageObjects.ads_iframe, Duration.ofSeconds(15));
    }

    /**
     * Hovers over the menu options on the  Warriors Home page.
     */
    public void hoverToMenu(){
        hoverOn( warriorsHomePageObjects.menu_options);
    }

    /**
     * Clicks on the 'News and Features' link and asserts that the URL 
     */
    public void clickNewsAndFeatures(){
        click( warriorsHomePageObjects.newsAndFeatures_link);
        Assert.assertTrue(getCurrentUrl().endsWith("/news"));
    }

    /**
     * Clicks on the 'Accept Cookies' button, if present, with an extended wait time.
     */
    public void acceptCookies(){
        click( warriorsHomePageObjects.accept_cookies_btn, Duration.ofSeconds(25));
    }

    /**
     * Attempts to close the pre-sales modal by clicking on its close button.
     * Ignores NoSuchElementException and TimeoutException.
     */
    public void clickPreSalesClose(){
        try {
            click( warriorsHomePageObjects.preSales_Modal_CloseBtn);
        } catch (NoSuchElementException | TimeoutException ignored){}
    }

    /**
     * Hovers over the 'Shop' dropdown menu.
     */
    public void hoverOnShop(){
        hoverOn( warriorsHomePageObjects.shop_drpdwn);
    }

    /**
     * Clicks on a specific shop category option in the dropdown menu.
     */
    public void clickOnShopOptions(String category){
        click( warriorsHomePageObjects.shop_drpdwnOption.updateCustomWebElement(
                 warriorsHomePageObjects.shop_drpdwnOption.getElement().replace("DropDownCategory",category),
                 warriorsHomePageObjects.shop_drpdwnOption.getComment().replace("DropDownCategory",category)));
    }
}
