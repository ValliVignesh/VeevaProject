package com.veevaAssignment.CPDP.stepDefinition;

import com.veevaAssignment.CPDP.objectRepository.NBAWarriorsHomePageObjects;
import com.veevaAssignment.CPDP.pages.warriorsHomePageActions;
import com.veevaAssignment.generic.keywords.GenericKeywords;
import com.veevaAssignment.utility.ReporterUtilities;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.model.Status;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;


public class WarriorsHomePageStepDefinition extends GenericKeywords {

    /** Constructs a new instance */
    public WarriorsHomePageStepDefinition(){}

    private final warriorsHomePageActions warriorsHomePageActions = new warriorsHomePageActions();

 
    @After
    public void after(Scenario scenario){
        if(scenario.isFailed()) {
            ReporterUtilities.updateTestStatus(Status.FAILED);
        } else {
            ReporterUtilities.updateTestStatus(Status.PASSED);
        }
        closeBrowsers();
    }


    /**
     * Opens a specified browser and loads a designated URL.
     * URLs are determined based on the provided product name.
     */
    @Given("Open {string} and load {string} URL")
    public void loadNBAURL(String browser, String productName){
        invokeBrowser(browser);
        if ("NBA Warrior".equals(productName)) {
            loadUrl(getProperty("warriorUrl"));
        } else if("NBA Bulls".equals(productName)) {
            loadUrl(getProperty("bullsURL"));
        }else if("NBA Sixers".equals(productName)) {
            loadUrl(getProperty("sixersURL"));
        }
    }

    //delete todo
    @Given("Open {string}")
    public void loadNBAURL(String browser) throws InterruptedException {
        invokeBrowser(browser);
        Thread.sleep(10000);
    }

    /**
     * Ensures the page is fully loaded by performing necessary actions like accepting cookies.
     */
    @When("Page is Loaded")
    public void pageIsLoaded() {
        warriorsHomePageActions.acceptCookies();
        try {
            warriorsHomePageActions.waitForAds();
        } catch (TimeoutException | NoSuchElementException ignored){}
    }


    /**
     * Navigates to a specific category's shop page.
     */
    @Then("Navigate to {string} shop now")
    public void navigateToCategoryShopNow(String category) {
        warriorsHomePageActions.hoverOnShop();
        warriorsHomePageActions.clickOnShopOptions(category);
    }

    /**
     * Navigates to a specific menu item, such as 'News and Features', on the NBA Warriors Home page.
     */
    @Then("Navigate to menu and to {string}")
    public void navigateToMenuAndToNewsAndFeatures(String menu) {
        warriorsHomePageActions.hoverToMenu();
        if(menu.equals("News and Features")) {
            warriorsHomePageActions.clickNewsAndFeatures();
        }
    }
}
