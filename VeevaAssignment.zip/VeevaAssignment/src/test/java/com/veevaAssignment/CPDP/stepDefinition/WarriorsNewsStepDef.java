package com.veevaAssignment.application.stepDefinition;

import com.veevaAssignment.application.objectRepository.NBAWarriorsHomePageObjects;
import com.veevaAssignment.application.pages.warriorsNewsPageStepDefinition;
import com.veevaAssignment.utility.ReporterUtilities;
import io.cucumber.java.en.Then;

/**
 for counting videos and determining the number of videos posted within mentioned duration
 */
public class WarriorsNewsPageStepDefinition {

    /** Constructs a new instance of the {@link WarriorsNewsPageStepDefinition} class. */
    public WarriorsNewsPageStepDefinition(){}

    private final warriorsNewsPageStepDefinition warriorsNewsPageStepDefinition = new warriorsNewsPageStepDefinition();


    @Then("Count overAll videos")
    public void countAllVideos(){
        int videoCount = warriorsNewsPageStepDefinition.getAllVideosSize();
        ReporterUtilities.log("Overall videos posted: " + videoCount);
    }

   
    @Then("Count videos {string} days")
    public void countVideosInRange(String numberOfDays){
        int videoCount = warriorsNewsPageStepDefinition.videosPostedInRange(numberOfDays);
        ReporterUtilities.log("Videos posted in " + numberOfDays + " days: " + videoCount);
    }
}
