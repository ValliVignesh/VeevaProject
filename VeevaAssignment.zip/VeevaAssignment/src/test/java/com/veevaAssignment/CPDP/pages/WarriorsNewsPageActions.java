package com.veevaAssignment.CPDP.pages;

import com.veevaAssignment.CPDP.objectRepository.WarriorsHomePageObjects;
import com.veevaAssignment.CPDP.objectRepository.WarriorsNewsPageObjects;
import com.veevaAssignment.generic.keywords.ElementWrapper;
import org.openqa.selenium.WebElement;

import java.time.LocalDate;

/**
 * Class containing actions that can be performed on the NBA Warriors News page.
 * Extends GenericKeywords to leverage common web interaction methods.
 */
public class WarriorsNewsPageActions extends ElementWrapper {

    /** Constructs a new instance */
    public WarriorsNewsPageActions(){}

    private final WarriorsNewsPageObjects warriorsNewsPageObjects = new WarriorsNewsPageObjects();

    /**
     * Gets the count of all video elements present on the  Warriors News page.
     */
    public int getAllVideosSize(){
        waitUntilVisible(warriorsNewsPageObjects.videos_modal);
        return getElements(warriorsNewsPageObjects.videos_modal).size();
    }

    /**
     * Counts the number of videos posted within a specific date duration.
     */
    public int videosPostedInRange(String range){
        int count = 0;
        for (WebElement element : getElements(warriorsNewsPageObjects.videos_modal)) {
            if (dateCompare(range, dateDifference(formattedDate(getAttributeValue(element.findElement(getByElement(warriorsNewsPageObjects.datePosted_txt)), "datetime"), "EEE MMM dd yyyy"), LocalDate.now())))
                count++;
        }
        return count;
    }

    /**
     * Compares a given date difference with a condition.
     */
    private boolean dateCompare(String condition, long validateNumber) {
        String[] parts = condition.split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
        return switch (parts[0]) {
            case ">=" -> validateNumber >= Integer.parseInt(parts[1]);
            case "<=" -> validateNumber <= Integer.parseInt(parts[1]);
            case ">" -> validateNumber > Integer.parseInt(parts[1]);
            case "<" -> validateNumber < Integer.parseInt(parts[1]);
            case "==" -> validateNumber == Integer.parseInt(parts[1]);
            default -> throw new IllegalArgumentException("Invalid operator: " + parts[0]);
        };
    }
}
