package com.veevaAssignment.CPDP.pages;

import com.veevaAssignment.CPDP.objectRepository.sixersPageActions;
import com.veevaAssignment.generic.keywords.ElementWrapper;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;

/**
 * Page actions class for the NBA Sixers page.
 * This class contains methods to interact with and perform actions on the NBA Sixers page.
 */
public class SixersPageActions extends ElementWrapper {

   /** Constructs a new instance */
   public SixersPageActions(){}

   private final sixersPageActions sixersPageObjects = new sixersPageActions();

   /**
    * Gets the total number of slides on the NBA Sixers page.
    */
   public int totalNumberOfSlides(){
      return getElements(sixersPageActions.slide_modal).size()-2;
   }

   /**
    * Moves to the first slide on the Sixers page.
    */
   public void moveToFirstSlide(){
      for(WebElement ele : getElements(sixersPageActions.slide_modal)){
         if(!ele.getAttribute("aria-label").startsWith("2 /"))
            click(sixersPageActions.slide_moveLeft_btn);
      }
   }

   /**
    * Validates the team title displayed on the slide modal.
    */
   public void validateTeamTitle(String title, String teamName) {
      for(WebElement element: getElements(sixersPageActions.slide_modal)){
         List<WebElement> teamNames = element.findElements(getByElement(sixersPageActions.slide_modal_teamsName_txt));
         if(teamNames.size()!= 0 && teamName.equalsIgnoreCase(teamNames.get(0).getText() +" vs "+teamNames.get(1).getText())){
            Assert.assertTrue(element.findElement(getByElement(sixersPageActions.slide_modal_teamsTitle_txt)).getText().equalsIgnoreCase(title));
            break;
         }else click(sixersPageActions.slide_moveRight_btn);
      }
   }

   /**
    * Clicks the "Watch Replay" button on the active slide modal.
    */
   public void clickWatchReplay(){
      getElement(sixersPageActions.activeSlide_modal).findElement(getByElement(sixersPageActions.watchReplay)).click();
   }

   /**
    * Clicks on the "Game Recap" button.
    */
   public void clickOnRecap(){
      click(sixersPageActions.gameRecap_btn);
   }

   /**
    * Waits until the AD gets over.
    */
   public void waitTillADGetsOver(){
      waitUntilPresent(sixersPageActions.advertiser_link, Duration.ofSeconds(20));
      waitUntilInvisible(sixersPageActions.advertiser_link, Duration.ofMinutes(5));
   }

   /**
    * Validates if the video is playing.
    */
   public void validateIsVideoPlaying() {
      waitUntilAttributePresent(sixersPageActions.video, Duration.ofSeconds(30), "data-playback", "playing");
   }
}