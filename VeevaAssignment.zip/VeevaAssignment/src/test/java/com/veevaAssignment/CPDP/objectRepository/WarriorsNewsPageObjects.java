package com.veevaAssignment.CPDP.objectRepository;

import com.veevaAssignment.custom.CustomWebElement;
import com.veevaAssignment.generic.Locators;

/**
 * Repository class for object locators of the NBA Warrior News page.
 * This class holds the locators for various elements on the NBA Warrior News page.
 */
public class WarriorsNewsPageObjects {

    /** Constructs a new instance*/
    public WarriorsNewsPageObjects(){}

    public CustomWebElement datePosted_txt = new CustomWebElement(Locators.TAGNAME, "time", "Date/Time video posted"); 
  
    public CustomWebElement videos_modal = new CustomWebElement(Locators.XPATH, "//h3[text()='VIDEOS']/../..//ul[@data-testid='content-grid-']//li", "Videos modal");

    
}
