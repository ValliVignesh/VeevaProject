package com.veevaAssignment.custom;

import com.veevaAssignment.generic.keywords.ElementWrapper;
import com.veevaAssignment.generic.Locators;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.List;

public class CustomWebElement {

    Locators locatorType;
    String element;
    String comment;

    public CustomWebElement(Locators locatorType, String element, String comment){
        this.locatorType = locatorType;
        this.element = element;
        this.comment = comment;
    }

    public CustomWebElement updateCustomWebElement(String element, String comment){
        this.element = element.isEmpty() ? this.element : element;
        this.comment = comment.isEmpty() ? this.comment : comment;
        return this;
    }

    public WebElement getWebElement() {
        return generateWebElement();
    }

    public String getElement() {
        return this.element;
    }

    private WebElement webElement;
    private By byElement;


    public List<WebElement> getWebElements() {
        return generateWebElements();
    }


    public String getComment() {
        return this.comment;
    }


    public WebElement reloadWebElement(){
        return generateWebElement();
    }


    private WebElement generateWebElement(){
        return new ElementWrapper().getDriver().findElement(findElement());
    }


    private List<WebElement> generateWebElements(){
        return new ElementWrapper().getDriver().findElements(findElement());
    }


    public By getByElement(){
        return byElement == null ? findElement() : byElement;
    }

  
    private By findElement(){
        return  switch (locatorType){
            case ID -> By.id(element);
            case XPATH -> By.xpath(element);
            case CLASSNAME -> By.className(element);
            case CSS -> By.cssSelector(element);
            case TAGNAME -> By.tagName(element);
            case LINKTEXT-> By.linkText(element);
        };
    }
}