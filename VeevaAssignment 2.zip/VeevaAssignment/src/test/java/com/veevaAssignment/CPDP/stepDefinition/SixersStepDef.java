package com.veevaAssignment.CPDP.stepDefinition;

import com.veevaAssignment.CPDP.pages.SixersPageActions;
import com.veevaAssignment.utility.ReporterUtility;

import io.cucumber.java.en.Then;

public class SixersStepDef {

    /** Constructs a new instance of the {@link SixersStepDef} class. */
    public SixersStepDef(){}

    private final SixersPageActions sixersPageActions = new SixersPageActions();

    /**
     * Collects and logs the total number of slides on the NBA Sixers page.
     */
    @Then("Collect total number of slides")
    public void collectTotalNumberOfSlides() {
        ReporterUtility.log("Total number of slides : " + sixersPageActions.totalNumberOfSlides());
    }

    /**
     * Validates the team title displayed on the slide modal.
     */
    @Then("Validate title {string} for team {string}")
    public void validateTitle(String title, String teamName) {
        sixersPageActions.moveToFirstSlide();
        sixersPageActions.validateTeamTitle(title, teamName);
    }

    /**
     * Clicks the "Watch Replay" button on the NBA Sixers page.
     */
    @Then("Click WatchReplay")
    public void clickWatchReplay() {
        sixersPageActions.clickWatchReplay();
    }

    /**
     * Clicks on the "Game Recap" button on the NBA Sixers page.
     */
    @Then("Click Game Recap")
    public void clickGameRecap() {
        sixersPageActions.clickOnRecap();
    }

    /**
     * Waits until the AD gets over on the NBA Sixers page.
     */
    @Then("Wait till AD gets over")
    public void waitTillADGetsOver() {
        sixersPageActions.waitTillADGetsOver();
    }

    /**
     * Validates if the video is playing on the NBA Sixers page.
     */
    @Then("Validate video is playing")
    public void validateProgressBar() {
        sixersPageActions.validateIsVideoPlaying();
    }
}
