package com.veevaAssignment.CPDP.stepDefinition;

import com.veevaAssignment.CPDP.objectRepository.WarriorsHomePageObjects;
import com.veevaAssignment.CPDP.pages.WarriorsNewsPageActions;
import com.veevaAssignment.utility.ReporterUtility;
import io.cucumber.java.en.Then;

/**
 for counting videos and determining the number of videos posted within mentioned duration
 */
public class WarriorsNewsStepDef {

    /** Constructs a new instance of the {@link WarriorsNewsPageStepDefinition} class. */
    public WarriorsNewsStepDef(){}

    private final WarriorsNewsPageActions warriorsNewsPageStepDefinition = new WarriorsNewsPageActions();


    @Then("Count overAll videos")
    public void countAllVideos(){
        int videoCount = warriorsNewsPageStepDefinition.getAllVideosSize();
        ReporterUtility.log("Overall videos posted: " + videoCount);
    }

   
    @Then("Count videos {string} days")
    public void countVideosInRange(String numberOfDays){
        int videoCount = warriorsNewsPageStepDefinition.videosPostedInRange(numberOfDays);
        ReporterUtility.log("Videos posted in " + numberOfDays + " days: " + videoCount);
    }
}
