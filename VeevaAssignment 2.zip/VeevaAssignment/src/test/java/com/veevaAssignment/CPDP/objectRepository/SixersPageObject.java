package com.veevaAssignment.CPDP.objectRepository;

import com.veevaAssignment.custom.CustomWebElement;
import com.veevaAssignment.generic.Locators;

/**
 * Repository class for object locators of the NBA Sixers page.
 * This class holds the locators for various elements on the NBA Sixers page.
 */
public class SixersPageObject {

    /** Constructs a new instance  */
    public SixersPageObject(){}


    public CustomWebElement slide_modal = new CustomWebElement(Locators.XPATH, "//div[contains(@class, 'swiper-slide-active')]/../div", "Slide modal");

   
    public CustomWebElement activeSlide_modal = new CustomWebElement(Locators.XPATH, "//div[contains(@class, 'swiper-slide-active')]", "Active Slide modal");


    public CustomWebElement slide_modal_teamsName_txt = new CustomWebElement(Locators.XPATH, ".//img/following-sibling::span", "Slide modal team's name");


    public CustomWebElement slide_modal_teamsTitle_txt = new CustomWebElement(Locators.XPATH, ".//div[contains(@class,'Game_gameHeader')]", "Slide modal team's title");

  
    public CustomWebElement slide_moveLeft_btn = new CustomWebElement(Locators.XPATH, "//button[@aria-label='Move left']", "Move Left button");

 
    public CustomWebElement slide_moveRight_btn = new CustomWebElement(Locators.XPATH, "//button[@aria-label='Move right']", "Move Right button");

    public CustomWebElement watchReplay = new CustomWebElement(Locators.XPATH, ".//a", "Watch replay button");


    public CustomWebElement gameRecap_btn = new CustomWebElement(Locators.XPATH, "//button[text()='Game Recap']", "Game recap button");


    public CustomWebElement video = new CustomWebElement(Locators.XPATH, "//video[@class]", "video");

   
    public CustomWebElement advertiser_link = new CustomWebElement(Locators.LINKTEXT, "Visit advertiser", "AD");
}
