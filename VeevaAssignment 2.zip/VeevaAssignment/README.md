
# Veeva Assignment for below case 

	# Test Case 2: for CP
	•	From the CP home page , hover on menu Item >> click on New & Features
	•	Count total number of Videos Feeds and count the videos feeds those are present in the page >= 3d


	# Test Case 3: for DP1
	•	Go to DP1 home page 
	•	Below Tickets Menu, count number of slides present
	•	Get the title of each Slide and validate with expected test data
	•	Count how much duration each slide is playing and validate with the expected duration

Tech Stack :

Java,
Cucumber
TestNG
Log4j


Required: 
- Java 
- Maven

Additional Inputs

To execute in local
1. Clone the repository:
2. mvn clean install
   
3. mvn test -Dcucumber.filter.tags="@regtests"
4. If allure not present
   allure serve allure-results